cccatalog-api contributors (sorted alphabetically by last name)
============================================

* **[Liza Daley](https://github.com/lizadaly)**
  * Built CC Search prototype, bits of which live on in this repository to this day
* **[Alden Page](https://github.com/aldenstpage)**
  * Author and maintainer of current implementation
