Requires Twisted for Python 2.7 and a running instance of Scrapy Cluster.

Ensures that rate limits are obeyed by the crawler.
